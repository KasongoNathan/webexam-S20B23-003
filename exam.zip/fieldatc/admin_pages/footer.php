<div id="footer">
	<p style="color:white;font-size:14px;margin-left:10px; padding-top:15px;">Copyright &copy; 2021 Uganda Christian University<a href="http://ucu.ac.ug" style='color:white;'>Thank You</a></p>
</div>
