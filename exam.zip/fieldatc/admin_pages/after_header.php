<div id="wrapper">
		<div id="header">
			<div class="box1">
					<h2 align="center" class="mar">Welcome <?php echo $_SESSION['name']; ?></h2>
			</div>
			<div class="box2">
				<table align="center" class="headlinks">
					<tr>
						<td><a href="home.php" class="head_links">Admin Panel</a></td>
						<td><a href="application.php" class="head_links">Application</a></td>
						<td><a href="logout.php" class="head_links">Logout</a></td>
					</tr>
				</table>
			</div>
		</div>