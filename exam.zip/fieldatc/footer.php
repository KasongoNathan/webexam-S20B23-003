<div id="footer">
	<p style="color:white;font-size:14px;margin-left:10px; padding-top:15px;">Copyright &copy; 2021 UGANDA CHRISTIAN UNIVERSITY | Programmed By: <a href="http://UCU.ac.ug" style='color:white;'>KASONGO NATHAN</a></p>
</div>
