<html>
<head>
	<title>IEEE | Field 2nd Year</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php
include 'header.php';
?>
		<?php
		include 'content.php';
		?>

	<?php
	include 'footer.php';
	?>
</body>
</html>
