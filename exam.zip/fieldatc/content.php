<div id="content">
			<?php
			include 'left.php';
			?>
			
			<?php
			include 'center.php';
			?>

			<?php
			include 'right.php';
			?>
			
		</div>
	</div>