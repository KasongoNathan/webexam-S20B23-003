<html>
<head>
	<title>IEEE | Field 2nd Year</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<?php
include 'header.php';
?>
		<div id="content">
		<?php
		include 'left.php';
		?>

		<div id="center">
	<h1 align="center" class="welcome">Fees & Financial</h1><hr>
	<h4 align="center">
		<h4 align="center" style="font-family:Lucida Bright;">
		 <?php
		 $query=mysqli_query($conn,"SELECT * FROM `contents` WHERE `id`='13'");
		 if ($row=mysqli_fetch_assoc($query)) {
		 	echo $row['full_contents'];

		 }
		 ?>
</h4>
</div></h4>

		<?php
		include 'right.php';
		?>
	</div>
</div>

	<?php
	include 'footer.php';
	?>
</body>
</html>
